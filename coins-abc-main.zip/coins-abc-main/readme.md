# Coins Project
## Version 0.1
* Folder and tool infrastructure
* Basic Coin class with tests and demo
