public class Quarter extends Coin {
    public Quarter(int year) {
        super(0.25, "Quarter", "IN GOD WE TRUST", year,
              "G_Washington", "Eagle", "E PLURIBUS UNUM",
              "LIBERTY", "UNITED STATES OF AMERICA", "QUARTER DOLLAR",
              true, "Cupro-Nickel");
    }
}
